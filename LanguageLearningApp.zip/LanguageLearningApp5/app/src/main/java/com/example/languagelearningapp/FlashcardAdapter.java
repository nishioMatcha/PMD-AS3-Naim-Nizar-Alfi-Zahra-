package com.example.languagelearningapp;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

public class FlashcardAdapter extends FragmentStateAdapter {

    private String[] questions;
    private String[] answers;

    public FlashcardAdapter(@NonNull FragmentActivity fragmentActivity, String[] questions, String[] answers) {
        super(fragmentActivity);
        this.questions = questions;
        this.answers = answers;
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        return new FlashcardFragment(questions[position], answers[position]);
    }

    @Override
    public int getItemCount() {
        return questions.length;
    }
}
