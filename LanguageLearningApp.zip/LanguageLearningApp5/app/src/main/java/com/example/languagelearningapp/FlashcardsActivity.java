package com.example.languagelearningapp;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;

public class FlashcardsActivity extends AppCompatActivity {

    private ViewPager2 viewPagerFlashcards;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flashcards);

        viewPagerFlashcards = findViewById(R.id.viewPagerFlashcards);

        // Example data for flashcards (questions and answers)
        String[] questions = {"What is 2 + 2?", "What is the capital of France?", "What is the color of the sky?"};
        String[] answers = {"4", "Paris", "Blue"};

        // Set up the adapter
        FlashcardAdapter adapter = new FlashcardAdapter(this, questions, answers);
        viewPagerFlashcards.setAdapter(adapter);
    }
}
