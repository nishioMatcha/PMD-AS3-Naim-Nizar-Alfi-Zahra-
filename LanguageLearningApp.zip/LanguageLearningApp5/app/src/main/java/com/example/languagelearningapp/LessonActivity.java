package com.example.languagelearningapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class LessonActivity extends AppCompatActivity {

    private Button btnFlashcards, btnQuiz, btnProgressTracker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lesson);

        // Initialize buttons from activity_lesson.xml
        btnFlashcards = findViewById(R.id.btnFlashcards);
        btnQuiz = findViewById(R.id.btnQuiz);
        btnProgressTracker = findViewById(R.id.btnProgressTracker);

        // Set up button click listeners
        btnFlashcards.setOnClickListener(v -> startActivity(new Intent(LessonActivity.this, FlashcardsActivity.class)));
        btnQuiz.setOnClickListener(v -> startActivity(new Intent(LessonActivity.this, QuizActivity.class)));
        btnProgressTracker.setOnClickListener(v -> startActivity(new Intent(LessonActivity.this, ProgressTrackerActivity.class)));
    }
}
