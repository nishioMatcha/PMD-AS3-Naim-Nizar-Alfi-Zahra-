package com.example.languagelearningapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText etUsername, etPassword, etConfirmPassword;
    private Button btnLogin, btnSignUp;
    private boolean isSignUp = false;  // Track if we're in sign-up mode

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize views
        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        etConfirmPassword = findViewById(R.id.etConfirmPassword);
        btnLogin = findViewById(R.id.btnLogin);
        btnSignUp = findViewById(R.id.btnSignUp);

        // Initially hide confirm password for login
        etConfirmPassword.setVisibility(View.GONE);

        // Handle Login button click
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = etUsername.getText().toString().trim();
                String password = etPassword.getText().toString().trim();

                // Validate login credentials
                if (username.equals("user") && password.equals("password")) {
                    Intent intent = new Intent(LoginActivity.this, LessonActivity.class);
                    startActivity(intent);
                    finish(); // Close the LoginActivity after successful login
                } else {
                    Toast.makeText(LoginActivity.this, "Invalid Login", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Handle SignUp button click
        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isSignUp) {
                    // If we're in sign-up mode, validate the sign-up process
                    String username = etUsername.getText().toString().trim();
                    String password = etPassword.getText().toString().trim();
                    String confirmPassword = etConfirmPassword.getText().toString().trim();

                    if (username.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
                        Toast.makeText(LoginActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                    } else if (!password.equals(confirmPassword)) {
                        Toast.makeText(LoginActivity.this, "Passwords do not match", Toast.LENGTH_SHORT).show();
                    } else {
                        // For demonstration, sign-up is successful
                        Toast.makeText(LoginActivity.this, "Sign Up Successful", Toast.LENGTH_SHORT).show();

                        // After sign-up, switch to login mode
                        isSignUp = false;
                        btnSignUp.setText("Sign Up");
                        etConfirmPassword.setVisibility(View.GONE);
                    }
                } else {
                    // Switch to sign-up mode
                    isSignUp = true;
                    btnSignUp.setText("Register");
                    etConfirmPassword.setVisibility(View.VISIBLE);
                }
            }
        });
    }
}
