package com.example.languagelearningapp;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ProgressTrackerActivity extends AppCompatActivity {

    private TextView tvProgress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_progress_tracker);

        tvProgress = findViewById(R.id.tvProgress);

        // Mock progress data
        int lessonsCompleted = 5;
        int quizzesCompleted = 3;
        tvProgress.setText("Lessons Completed: " + lessonsCompleted + "\nQuizzes Completed: " + quizzesCompleted);
    }
}
